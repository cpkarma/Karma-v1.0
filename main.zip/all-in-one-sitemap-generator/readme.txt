===================All In One Sitemap Generator=========================

Contributors: techsurvi
Description: create a sitemap in xml and txt format.
Version: 1.0
Author: Techsurvi
Author URI: https://www.techsurvi.com
Text Domain: All In One Sitemap Generator
Domain Path: /languages/
Requires at least: 3.5.0
Tested up to: 5.5.1
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Create sitemap in XML and txt format and robots editor.
========================Description======================================
All in one sitemap generate sitemap in both XML and TXT format for your website.The plugin will show page, posts and also your other custom post type like products.
Add custom entries in robots.txt file.
Automatic daily auto ping to google when you have updated pages or posts in Wordpress.
=======================Installation======================================
*Manual install

Upload the All In One Sitemap Generator folder to the /wp-content/plugins/ directory.
Activate the plugin through the Plugins menu in WordPress.
Access the generator with the All in one sitemap  button in the sidebar and use the checkbox  buttons to start the generation process in xml or txt format. The sitemap will be saved as allinonesitemap.xml in your WordPress root directory.

*Via Wordpress

Search for  All In One Sitemap Generator 
1. Click install.
1. Activate.
========================Change log======================================
1.0 Initial Release		





